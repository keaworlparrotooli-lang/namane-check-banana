나만의 체크 - 바나나 Android 테스트 빌드 묶음

패키지 이름: com.namanecheck.banana
포함된 앱 화면: app/src/main/assets/index.html (사용자가 제공한 원본)

중요:
- 이 묶음은 Android WebView 테스트용 프로젝트와 GitHub Actions 빌드 설정입니다.
- 아직 APK가 아닙니다. GitHub에 업로드하고 Actions를 실행해야 APK가 생성됩니다.
- 이 APK는 화면/로컬 기능 확인용 테스트 빌드입니다.
- 현재 HTML의 Google 로그인은 웹 팝업 방식입니다. Android WebView에서는 Google OAuth 팝업이 정상 동작하지 않을 수 있으므로, 실제 출시 전에는 네이티브 Google 로그인 방식으로 별도 연결하고 Firebase 동작을 실기기에서 검증해야 합니다.
- 서명된 Play 배포용 AAB도 별도로 만들어야 합니다.

GitHub 휴대폰 웹사이트에서:
1. 저장소 나만의-체크-바나나 열기
2. Add file > Upload files
3. 이 ZIP을 압축 해제한 뒤 안의 파일/폴더를 저장소 최상위에 업로드
4. Commit changes
5. Actions 탭 > Build test APK > Run workflow
6. 실행이 끝나면 Artifacts의 namane-banana-debug-apk를 눌러 다운로드
7. ZIP 안의 app-debug.apk를 갤럭시에 설치

주의: 기존 저장소 파일과 이름이 겹치면 덮어쓰기 전에 백업하세요.
