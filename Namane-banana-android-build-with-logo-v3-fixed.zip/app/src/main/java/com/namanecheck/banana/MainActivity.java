package com.namanecheck.banana;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class MainActivity extends Activity {
    private static final int RC_GOOGLE_SIGN_IN = 7001;
    // Firebase 프로젝트의 Web OAuth client ID (google-services.json의 client_type 3)
    private static final String WEB_CLIENT_ID = "111221307174-h3umn0b5377qv8fmgevgpdo3amck62u6.apps.googleusercontent.com";
    private WebView webView;
    private GoogleSignInClient googleSignInClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestIdToken(WEB_CLIENT_ID)
            .build();
        googleSignInClient = GoogleSignIn.getClient(this, options);

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.addJavascriptInterface(new GoogleBridge(), "AndroidGoogleAuth");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(
                WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private class GoogleBridge {
        @JavascriptInterface
        public void signIn() {
            runOnUiThread(() -> startActivityForResult(googleSignInClient.getSignInIntent(), RC_GOOGLE_SIGN_IN));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_GOOGLE_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                String token = account.getIdToken();
                if (token == null || token.isEmpty()) {
                    sendAuthError("Google ID 토큰을 받지 못했어요. OAuth 설정을 확인해 주세요.");
                } else {
                    String safeToken = org.json.JSONObject.quote(token);
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "window.nmcOnNativeGoogleToken && window.nmcOnNativeGoogleToken(" + safeToken + ");", null));
                }
            } catch (ApiException e) {
                sendAuthError("Google 로그인에 실패했어요. 오류 코드: " + e.getStatusCode());
            }
        }
    }

    private void sendAuthError(String message) {
        String safeMessage = org.json.JSONObject.quote(message);
        runOnUiThread(() -> webView.evaluateJavascript(
            "window.nmcOnNativeGoogleError && window.nmcOnNativeGoogleError(" + safeMessage + ");", null));
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
